import tkinter as tk
from tkinter import *
from tkinter.messagebox import showinfo
import sqlite3
from tkcalendar import *

# Creates new Tk() object
root = tk.Tk()
# Title of GUI Application
root.title("Rykers Ridge Blueberry")

# Display Message upon opening at the top
message = tk.Label(root, text="Welcome to Rykers Ridge Blueberry!")
message.pack()

message = tk.Label(root, text="Would you like to order blueberries today or schedule a date to come pick blueberries?")
message.pack()

# Fixed application size of main screen
root.geometry('1000x700+50+50')
root.resizable(False, False)
root.iconbitmap('C:/Users/Zach/Desktop/BlueBerry GUI Application/R.ico')

# Database - Contains Names, Phone Numbers and Orders
conn = sqlite3.connect('address_book.db')
# Create cursor
c = conn.cursor()

# Create Table
c.execute("""CREATE TABLE addresses (
        firstName text,
        lastName text,
        phoneNumber interger
        )""")

# Commit Changes
conn.commit()

# CLose Connection
conn.close()

# Ordering system with radio buttons
class Application():

    def blueberrySize():
        import tkinter as tk
        from tkinter import Toplevel, ttk

        def orderReceived():
            Received = Toplevel()

            Received.title("Order submitted!")

            tk.Label(orderReceived, text="Thank you for ordering blueberries! You may return to the home page!").pack()

            tk.Button(orderReceived, text="Main Menu", command=lambda: orderReceived.quit()).pack()

            orderReceived.geometry("300x300")

    # Toplevel object which will be treated as a new window
        Blueberries = Toplevel()
 
    # sets the title of the Toplevel widget
        Blueberries.title("Blueberries")

    # A Label widget to show in toplevel
        tk.Label(Blueberries, text ="How much blueberries would you like to order?").pack()

    # Varying sizes for order placement
        selected_size = tk.StringVar()
        sizes = (('1lb bag', '1 lb ordered! Thank you!'),
             ('2lb bag', '2 lbs ordered! Thank you!'),
             ('3lb bag', '3 lbs ordered! Thank you!'),
             ('4lb bag', '4 lbs ordered! Thank you!'),
             ('5lb bag', '5 lbs ordered! Thank you!'))

    # radio buttons
        for size in sizes:
            r = ttk.Radiobutton( Blueberries, text=size[0], value=size[1], variable=selected_size)
            r.pack(fill='x', padx=5, pady=5)

    # button
        button = ttk.Button( Blueberries, text="Order Selected Size", command= orderReceived)
        button.pack(fill='x', padx=5, pady=5)
    
    # sets the geometry of toplevel
        Blueberries.geometry("300x300")
        return blueberrySize

blueberrySize = Application()

# Scheduling system for pick-a-date
def blueberryPickDate():

    # Toplevel object which will be treated as a new window
    pickDate = Toplevel()
 
    # sets the title of the Toplevel widget
    pickDate.title("Pick-a-Date")

    # sets the geometry of toplevel
    pickDate.geometry("300x300")
    
    # Label in widget to show in toplevel
    tk.Label(pickDate, text="When would you like to come pick blueberries?").pack(padx=10, pady=10)

    cal = DateEntry(pickDate, width=12, background='darkblue',
                    foreground='white', borderwidth=2)
    cal.pack(padx=10, pady=10)

# This button opens a new window in which you will order blueberries
Button(root, text ="Click to order Blueberries!", command = blueberrySize).pack(pady = 10)

# This button opens a new window in which you schedule a date
Button(root, text ="Click to Pick-a-Date!", command = blueberryPickDate).pack(pady = 10)

# exit button
exit_button = tk.Button( root, text='Exit', command=lambda: root.quit()) 
exit_button.pack(ipadx=5, ipady=5, expand=True)


try:
    from ctypes import windll

    windll.shcore.SetProcessDpiAwareness(1)
finally:
    root.mainloop()